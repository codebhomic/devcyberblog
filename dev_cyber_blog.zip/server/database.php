<?php
return [
    'dbhost' => "localhost",
    'dbUsername' => "root",
    'dbPassword' => "",
    'dbName' => "devcyberblog",
];
?>