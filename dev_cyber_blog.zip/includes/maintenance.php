<?php
return [
    'maintenance_mode' => false,
];
?>