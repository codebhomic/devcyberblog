<!DOCTYPE html>
<html>

<head>
    <title>400 Not Found</title>
</head>

<body>
    <h1>400 error Bad Request</h1>
    <p>Sorry, the page you are looking for has bad request error please check the link again.</p>
</body>

</html>