<!DOCTYPE html>
<html>

<head>
    <title>404 Not Found</title>
</head>

<body>
    <h1>Page Not Found</h1>
    <p>Sorry, the page you are looking for does not exist.</p>
</body>

</html>